<?php
// Heading
$_['heading_title'] = 'Error :';

// Text
$_['text_customer'] = '<p> The Payment is rejected or canceled<p>';
$_['text_checkout'] = 'Checkout';
$_['text_guest']    = '<p> The Payment is rejected or canceled<p>';
?>